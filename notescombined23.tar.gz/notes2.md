

## Linux notes
- man
- mkdir winter summer
- to run scripts: ./yourscript.sh
- ls -l
- mkdir -p winter/seeds/lettuce (will create alldir, also seeds)
- cd / or cd ~
- touch (used to create blank file or create timestamp)
- rm carrot cat dog
- rm -v carrot cat dog (verbose, means shows what it is doing)
- open . (opens the current directoty) / open purple.txt (will open in desktop)
- mv filenamecurrent filenamenew
- mv filenamecurrnet ~/Desktop
- mv folder/ folder/
- cp -r folder ~/Desktop
- head filename.txt (shows first 10 lines)
- tail -f filaname (continuesly shows last 10 lines)
- date > current_date.txt 
- date >> list_of_dates.txt
- cat


## Git notes 
- git init
- git add README.md
- git commit -m "first commit"
- git branch -M main
- git remote add origin https://github.com/D5mit/code_notes.git
- git push -u origin main
- git pull
- git merge comments 







